import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part '../../../../generated/shared/services/dialogs/snackbar/snackbar_model.freezed.dart';

/// Snackbars
@freezed
class SnackbarModel with _$SnackbarModel {
  const factory SnackbarModel({
    String? text,
    String? subText,
    String? cancelActionText,
    Duration? duration,
    IconData? iconData,
    String? actionText,
  }) = _SnackbarModel;

  /// info dialog model
  factory SnackbarModel.info() => const SnackbarModel(
        iconData: Icons.info,
      );

  /// confirm dialog model
  factory SnackbarModel.warning() =>
      const SnackbarModel(iconData: Icons.warning);
}
