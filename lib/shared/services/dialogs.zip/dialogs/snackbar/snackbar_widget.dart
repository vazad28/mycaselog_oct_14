import 'package:flutter/material.dart';

import '../../../../core/core.dart';
import 'snackbar_model.dart';

ScaffoldFeatureController<SnackBar, SnackBarClosedReason>? showCustomSnackBar(
  SnackbarModel snackbarModel,
  ThemeData theme,
) {
  AppVars.appScaffoldMessengerKey.currentState?.removeCurrentSnackBar();
  AppVars.appScaffoldMessengerKey.currentState?.hideCurrentSnackBar();

  final snackbarWidget = SnackbarWidget(snackbarModel: snackbarModel);

  return AppVars.appScaffoldMessengerKey.currentState?.showSnackBar(
    SnackBar(
      content: snackbarWidget,
      backgroundColor: theme.colorScheme.inverseSurface.withValues(alpha: 200),
      duration: snackbarModel.duration ?? const Duration(seconds: 4),
      action: snackbarModel.actionText != null
          ? SnackBarAction(
              textColor: theme.colorScheme.onTertiary,
              label: snackbarModel.actionText!,
              onPressed: () {},
            )
          : null,
    ),
  );
}

///
/// Snackbar content widget
///
class SnackbarWidget extends StatelessWidget {
  const SnackbarWidget({required this.snackbarModel, super.key});

  final SnackbarModel snackbarModel;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      shrinkWrap: true,
      // mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(
              snackbarModel.iconData ?? Icons.info,
              color: theme.colorScheme.onInverseSurface,
            ),
            const SizedBox(
              width: 8,
            ),
            Flexible(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Flexible(
                    child: Text(
                      snackbarModel.text ?? 'No text',
                      softWrap: true,
                      textAlign: TextAlign.start,
                      // style: iconAndTextColor != null
                      //     ? const TextStyle()
                      //         .copyWith(color: iconAndTextColor)
                      //     : null,
                    ),
                  ),
                  if (snackbarModel.subText != null)
                    Flexible(
                      child: Text(
                        snackbarModel.subText!,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onInverseSurface,
                        ),
                        softWrap: true,
                        textAlign: TextAlign.start,
                      ),
                    )
                  else
                    const SizedBox(),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}
